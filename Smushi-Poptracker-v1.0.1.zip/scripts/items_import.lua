Tracker:AddItems("items/items.jsonc")
Tracker:AddItems("items/settings.jsonc")
Tracker:AddItems("items/level_display.jsonc")