
------------------------------------------------------------------
-- Configuration options for scripted systems in this pack
------------------------------------------------------------------
AUTOTRACKER_ENABLE_ITEM_TRACKING = true
AUTOTRACKER_ENABLE_LOCATION_TRACKING = true
ENABLE_DEBUG_LOG = true
AUTOTRACKER_ENABLE_DEBUG_LOGGING = true
