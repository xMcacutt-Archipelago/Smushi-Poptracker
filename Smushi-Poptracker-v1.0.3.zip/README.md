# Smushi-poptracker
Poptracker for Smushi Come Home Archipelago for [PopTracker](https://github.com/black-sliver/PopTracker)

**How To Use :**
- Download the latest version of [PopTracker](https://github.com/black-sliver/PopTracker/releases)
- Download the latest version of [this tracker]()
- Copy the tracker zip file inside the 'packs' folder of PopTracker


# Credits
Thanks to FyreDay for the basis of this poptracker, DashieSwag92 for assistance with building the logic, and the Smushi Speedrunning community for documenting logic.